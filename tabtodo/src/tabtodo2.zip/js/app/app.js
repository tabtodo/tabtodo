﻿//var myApp = angular.module('tabtodo', []);
var myApp = angular.module('tabtodo', [ 'ui.sortable', 'ngDialog' ]);